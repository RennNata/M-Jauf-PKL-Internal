<?php
// ================================================
// FILE: app/Http/Controllers/HomeController.php
// FUNGSI: Menangani halaman utama website
// ================================================

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class HomeController extends Controller
{
    /**
     * Menampilkan halaman beranda.
     *
     * Halaman ini menampilkan:
     * - Hero section (static)
     * - Kategori populer
     * - Produk unggulan (featured)
     * - Produk terbaru
     */
    public function index()
    {
        // ================================================
        // AMBIL DATA KATEGORI
        // - Hanya yang aktif
        // - Hitung jumlah produk di masing-masing kategori
        // ================================================
        $categories = Category::query()
            ->active()                    // Scope: hanya is_active = true
            ->withCount(['activeProducts' => function($q) {
                $q->where('is_active', true)
                  ->where('stock', '>', 0);
            }])
            ->having('active_products_count', '>', 0)  // Hanya yang punya produk
            ->orderBy('name')
            ->take(6)                     // Batasi 6 kategori
            ->get();

        // ================================================
        // PRODUK UNGGULAN (FEATURED)
        // - Flag is_featured = true
        // - Aktif dan ada stok
        // ================================================
        $featuredProducts = Product::withCount(['orderItems as total_sales' => function($query) {
        $query->select(DB::raw('sum(quantity)'));
        }])
        ->orderByDesc('total_sales')
        ->take(4) // Ambil 4 produk teratas
        ->get();

        // ================================================
        // PRODUK TERBARU
        // - Urutkan dari yang paling baru
        // ================================================
        $latestProducts = Product::query()
            ->with(['category', 'primaryImage'])
            ->active()
            ->inStock()
            ->latest()         // Order by created_at DESC
            ->take(8)
            ->get();

        // ================================================
        // KIRIM DATA KE VIEW
        // compact() membuat array ['key' => $key]
        // ================================================
        return view('home', compact(
            'categories',
            'featuredProducts',
            'latestProducts'
        ));
    }
}